package com.example.demo;

 

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.domain.Author;
import com.example.demo.domain.Paper;
import com.example.demo.domain.Reviewer;
import com.example.demo.domain.User;
import com.example.demo.domain.Writes;
import com.example.demo.domain.participator;
import com.example.demo.service.ParticipatorServices;

 

@Controller
public class loginSignUpController {
    @Autowired
    ParticipatorServices partService;

 

	@RequestMapping(value = "/newParticipator", method = RequestMethod.GET)

	public String newParticipator(@ModelAttribute participator newParticipator, @ModelAttribute Author authorRole,

			@ModelAttribute Reviewer revRole, Model model) {

		newParticipator = new participator("", "", "", "", "", "", "");

		authorRole = new Author("");

		revRole = new Reviewer("");

		model.addAttribute("authorRole", authorRole);

		model.addAttribute("revRole", revRole);

		model.addAttribute("newParticipator", newParticipator);

		return "newParticipator";

	}
 

	@RequestMapping(value = "/createNewParticipator", method = RequestMethod.POST)

	public String saveEmployee(@ModelAttribute participator participator, @ModelAttribute Author authorRole,

			@ModelAttribute Reviewer revRole, Model model) {

		partService.createNewParticipator(participator);

		partService.createNewAuthorRole(authorRole);

		partService.createNewReviewerRole(revRole);

		model.addAttribute("participator", participator);

		model.addAttribute("authorRole", authorRole);

		model.addAttribute("revRole", revRole);

		model.addAttribute("message", "New Participator Added Successfully");

		return "newParticipator";

	}
     
     
     
    //Login Stuff 
     
     
     @RequestMapping(value = "/login", method = RequestMethod.GET)
	    public String userList(Map <String,Object> model) {
    	 
    	 model.put("user",new User("","")); 
	        return "login";
	    }
    
     @RequestMapping(value = "/home", method = RequestMethod.POST)
	    public String verifyLogin( @ModelAttribute User user, Model model,RedirectAttributes redirectAttributes) {
    	 
    	 
    	 participator  LoggedInParticipator = new participator ("","", "", "", "", "", "");
    	 LoggedInParticipator = partService.getLoggedinParticipator(user);
         model.addAttribute("LoggedInParticipator",LoggedInParticipator);
    	 
    	 List<User> userList = new ArrayList<User>();  
    	 userList = partService.verifyLogin(user);
	     model.addAttribute("userList",userList);
	     model.addAttribute("user",user);
	     
	     List<Paper> AuthoredPapersList = new ArrayList<Paper>();  
		 AuthoredPapersList = partService.getAuthorPapers(user);
	     model.addAttribute("AuthoredPapersList",AuthoredPapersList);
	     
	     
	     List<Paper> ReviewedPapersList = new ArrayList<Paper>();  
	     ReviewedPapersList = partService.getAuthorReviews(user);
	     model.addAttribute("ReviewedPapersList",ReviewedPapersList);
	     
	     if(userList.isEmpty()){
	    	    model.addAttribute("message","Ivalid Username or Password");
	            return "/login";
	        }
	     
	     else{
	    	 redirectAttributes.addFlashAttribute("user", user); 
	    	 return "/HomePage";
	     }
	     
	    }
     
     
     @RequestMapping(value = "/home", method = RequestMethod.GET)
	    public String afterLogin( @ModelAttribute User user, Model model,RedirectAttributes redirectAttributes) {
 	 
 	 
 	 participator  LoggedInParticipator = new participator ("","", "", "", "", "", "");
 	 LoggedInParticipator = partService.getLoggedinParticipator(user);
      model.addAttribute("LoggedInParticipator",LoggedInParticipator);
 	 
 	 List<User> userList = new ArrayList<User>();  
 	 userList = partService.verifyLogin(user);
	     model.addAttribute("userList",userList);
	     model.addAttribute("user",user);
	     
	     List<Paper> AuthoredPapersList = new ArrayList<Paper>();  
		 AuthoredPapersList = partService.getAuthorPapers(user);
	     model.addAttribute("AuthoredPapersList",AuthoredPapersList);
	     
	     
	     List<Paper> ReviewedPapersList = new ArrayList<Paper>();  
	     ReviewedPapersList = partService.getAuthorReviews(user);
	     model.addAttribute("ReviewedPapersList",ReviewedPapersList);
	     
	     if(userList.isEmpty()){
	    	    model.addAttribute("message","Ivalid Username or Password");
	            return "/login";
	        }
	     
	     else{
	    	 redirectAttributes.addFlashAttribute("user", user); 
	    	 return "/HomePage";
	     }
	     
	    }
     
     
}