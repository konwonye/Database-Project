package com.example.demo.dao;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;
import com.example.demo.dao.domain.ConferenceMapper;
import com.example.demo.domain.AllPaper;
import com.example.demo.domain.Paper;
import com.example.demo.domain.User;
import com.example.demo.domain.Writes;

@Component
public class paperDAO {
	
	@Autowired
	private ConferenceMapper conferenceMapper;

	public List<Paper> getAuthorPapers(User user) {
		
		List<Paper> AuthorPaperList = new ArrayList<Paper>();
		
		AuthorPaperList = conferenceMapper.getAuthorPapers(user);
		
		return AuthorPaperList;
	}

	public Paper getPaperDetails(Paper paper) {
		// TODO Auto-generated method stub
		Paper PaperSelected = new Paper("", "", "", "", "");
		PaperSelected = conferenceMapper.PaperDetails(paper);
		
		return PaperSelected;
	}

	public List<Paper> getPaperList() {
        
        List<Paper> paperList = new ArrayList <Paper>();
       
        paperList = conferenceMapper.getPaperList();
       
        return paperList;

}
	
	
public List<AllPaper> getAllPaperList() {
        
        List<AllPaper> paperList = new ArrayList <AllPaper>();
       
        paperList = conferenceMapper.getAllPaperList();
       
        return paperList;

}
	public void createNewPaper(Paper paper) {
		conferenceMapper.createNewPaper(paper);	
	}
	
	public void createNewAuthors(Writes paperAuthor) {
		conferenceMapper.createNewAuthors(paperAuthor);
	}
	
	public Integer getMaxPaperID() {
		Integer maxPaperID = conferenceMapper.maxPaperID();
		return maxPaperID;
	}

	public  List<Paper> getAuthorReviews(User user) {
		// TODO Auto-generated method stub
		List<Paper> ReviewPapersList = new ArrayList<Paper>();
		
		
		ReviewPapersList = conferenceMapper.getAuthorReviews(user);
		
		
		return ReviewPapersList;
	}

}

