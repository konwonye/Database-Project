package com.example.demo.domain;

public class AllPaper {
    
    private String paperId;
    private String title;
    private String avgRecommend;
    
    

 

    public AllPaper(String paperId, String title, String avgRecommend) {
        
        
        super();
        
        
        this.setPaperId(paperId);
        this.setTitle(title);
        this.setAvgRecommend(avgRecommend);
    }

 

 

    /**
     * @return the paperId
     */
    public String getPaperId() {
        return paperId;
    }

 

 

    /**
     * @param paperId the paperId to set
     */
    public void setPaperId(String paperId) {
        this.paperId = paperId;
    }

 

 

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

 

 

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
        
        
    }
    /**
     * @return the avgRecommend
     */
    public String getAvgRecommend() {
        return avgRecommend;
    }

 

 

    /**
     * @param avgRecommend the avgRecommend to set
     */
    public void setAvgRecommend(String avgRecommend) {
        this.avgRecommend = avgRecommend;
    }
}