package com.example.demo.domain;

 

public class Paper {
    
    private String paperId;
    private String title;
    private String paperAbstract;
    private String fileName;
    private String OverallRecommendation;
    private String contactAuthorEmail;
    
    

 

    public Paper(String paperId, String title, String paperAbstract, String fileName, 
            String contactAuthorEmail) {
        
        
        super();
        
        
        this.setPaperId(paperId);
        this.setTitle(title);
        this.setPaperAbstract(paperAbstract);
        this.setFileName(fileName);
        this.setContactAuthorEmail(contactAuthorEmail);
    }

 

 

    /**
     * @return the paperId
     */
    public String getPaperId() {
        return paperId;
    }

 

 

    /**
     * @param paperId the paperId to set
     */
    public void setPaperId(String paperId) {
        this.paperId = paperId;
    }

 

 

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

 

 

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

 

 

    /**
     * @return the paperAbstract
     */
    public String getPaperAbstract() {
        return paperAbstract;
    }

 

 

    /**
     * @param paperAbstract the paperAbstract to set
     */
    public void setPaperAbstract(String paperAbstract) {
        this.paperAbstract = paperAbstract;
    }

 

 

    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }

 

 

    /**
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

 

 

    /**
     * @return the contactAuthorEmail
     */
    public String getContactAuthorEmail() {
        return contactAuthorEmail;
    }

 

 

    /**
     * @param contactAuthorEmail the contactAuthorEmail to set
     */
    public void setContactAuthorEmail(String contactAuthorEmail) {
        this.contactAuthorEmail = contactAuthorEmail;
    }

 

 

    public String getOverallRecommendation() {
        return OverallRecommendation;
    }

 

 

    public void setOverallRecommendation(String overallRecommendation) {
        OverallRecommendation = overallRecommendation;
    }
    

 

}