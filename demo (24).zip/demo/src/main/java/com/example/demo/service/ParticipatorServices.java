package com.example.demo.service;
import com.example.demo.domain.Reviews;
import com.example.demo.domain.User;
import com.example.demo.domain.Writes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

import com.example.demo.domain.AllPaper;
import com.example.demo.domain.Author;
import com.example.demo.domain.Paper;
import com.example.demo.domain.Reviewer;
import com.example.demo.domain.participator;
import com.example.demo.dao.participatorDAO;
import com.example.demo.dao.reviewsDAO;
import com.example.demo.dao.paperDAO;

@Component
public class ParticipatorServices {
	@Autowired
	participatorDAO participatorDAO;
	public List<participator> getParticipatorList(){
		
			List<participator> participatorList = new ArrayList<participator>();
			
			
			participatorList = participatorDAO.getParticipatorList();
			
			
			return participatorList;
		
	}

	
	@Autowired
	paperDAO paperDAO;
	public List<Paper> getAuthorPapers(User user){
		
			List<Paper> AuthorPapersList = new ArrayList<Paper>();
			
			
			AuthorPapersList = paperDAO.getAuthorPapers(user);
			
			
			return AuthorPapersList;
		
	}
	public Paper selectedPaper(Paper paper) {
		// TODO Auto-generated method stub
		Paper PaperSelected = new Paper("", "", "", "", "");
		
		
		PaperSelected = paperDAO.getPaperDetails(paper);
		
		
		return PaperSelected;
	}
	
    public List<Paper> getPaperList() {
        
        List<Paper> paperList = new ArrayList<Paper>();
           
        paperList = paperDAO.getPaperList();
           
           
        return paperList;
        }
    
    public List<AllPaper> getAllPaperList() {
        
        List<AllPaper> paperList = new ArrayList<AllPaper>();
           
        paperList = paperDAO.getAllPaperList();
           
           
        return paperList;
        }
	
	
	public List<participator> getPaperAuthors(Paper paper) {
		// TODO Auto-generated method stub
		List<participator> PaperAuthorsList = new ArrayList<participator>();
		PaperAuthorsList = participatorDAO.getPaperAuthors(paper);
		return PaperAuthorsList;
	}
	
	
	
	@Autowired
	reviewsDAO reviewsDAO;
	public List<Reviews> getPaperReviews(Paper paper) {
		// TODO Auto-generated method stub
		List<Reviews> PaperReviewsList = new ArrayList<Reviews>();
		PaperReviewsList = reviewsDAO.getPaperReviews(paper);
		return PaperReviewsList;
	}
	

	public void createNewReview(Reviews review) {
		reviewsDAO.createNewReview(review);
	}
	
	
	public void createNewPaper(Paper paper) {
		paperDAO.createNewPaper(paper);	
	}
	
	public void createNewAuthors(Writes paperAuthor) {
		paperDAO.createNewAuthors(paperAuthor);	
	}
	
	public void createNewParticipator(participator participator) {
        // TODO Auto-generated method stub
        participatorDAO.createNewPrticipator(participator);
    }
	
	public Integer getMaxPaperID() {
		Integer maxPaperID = paperDAO.getMaxPaperID();
		maxPaperID= maxPaperID + 1;
		return maxPaperID;
	}
	public List<User> verifyLogin(User user) {
		// TODO Auto-generated method stub
		
		List<User> userList = new ArrayList<User>();
		userList= participatorDAO.verifyLogin(user);
		
		return userList;
	}
	public List<Paper> getAuthorReviews(User user) {
		// TODO Auto-generated method stub
		
		List<Paper> ReviewPapersList = new ArrayList<Paper>();
		
		
		ReviewPapersList = paperDAO.getAuthorReviews(user);
		
		
		return ReviewPapersList;
		
	}
	public participator getLoggedinParticipator(User user) {
		// TODO Auto-generated method stub
		participator LoggedInParticipator = new participator("", "", "", "", "", "", "");
		LoggedInParticipator = participatorDAO.getLoggedinParticipator(user);
		return LoggedInParticipator;
	}

	public void createNewAuthorRole(Author authorRole) {

		participatorDAO.createNewAuthorRole(authorRole);

	}

	public void createNewReviewerRole(Reviewer revRole) {

		participatorDAO.createNewReviewerRole(revRole);

	}
	
}
