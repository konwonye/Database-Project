package com.example.demo.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.dao.domain.ConferenceMapper;
import com.example.demo.domain.Paper;
import com.example.demo.domain.Reviews;

@Component
public class reviewsDAO {
	
	@Autowired
	private ConferenceMapper conferenceMapper;
	
	public List<Reviews> getPaperReviews(Paper paper) {
		// TODO Auto-generated method stub
		List<Reviews> PaperReviewsList = new ArrayList<Reviews>();
		PaperReviewsList = conferenceMapper.getPaperReviews(paper);
		return PaperReviewsList;
	}

	public void createNewReview(Reviews review) {
		conferenceMapper.createNewReview(review);
	}

}
