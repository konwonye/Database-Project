package com.example.demo;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.domain.Paper;
import com.example.demo.domain.User;
import com.example.demo.domain.participator;
import com.example.demo.service.ParticipatorServices;
import com.example.demo.service.ParticipatorServices;

@Controller
public class HomePageController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomePageController.class);
	
	@Autowired
	ParticipatorServices partService;
	
	 @RequestMapping(value = "/homefrf", method = RequestMethod.GET)
	    public String userHomepage(@ModelAttribute User user, Model model) {
	    	
    	 
    	 participator  LoggedInParticipator = new participator ("","", "", "", "", "", "");
    	 LoggedInParticipator = partService.getLoggedinParticipator(user);
         model.addAttribute("LoggedInParticipator",LoggedInParticipator);
    	 
    	 List<User> userList = new ArrayList<User>();  
    	 userList = partService.verifyLogin(user);
	     model.addAttribute("userList",userList);
	     model.addAttribute("user",user);
	     
	     List<Paper> AuthoredPapersList = new ArrayList<Paper>();  
		 AuthoredPapersList = partService.getAuthorPapers(user);
	     model.addAttribute("AuthoredPapersList",AuthoredPapersList);
	     
	     
	     List<Paper> ReviewedPapersList = new ArrayList<Paper>();  
	     ReviewedPapersList = partService.getAuthorReviews(user);
	     model.addAttribute("ReviewedPapersList",ReviewedPapersList);
	     
	        return "HomePage";
	    }
	 
	 
	 
}
