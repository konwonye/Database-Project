package com.example.demo;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.domain.Reviews;
import com.example.demo.service.ParticipatorServices;



@Controller
public class ReviewSubmissionController {
	
	private static final Logger logger = LoggerFactory.getLogger(ReviewSubmissionController.class);
	
	@Autowired
	ParticipatorServices partService;
	
    
    @RequestMapping(value = "/newReview", method = RequestMethod.GET)
    public String newReview(@ModelAttribute Reviews review, Model model) {

    	review = new Reviews("", "", "", "", "", "", "", "", "");
    	model.addAttribute("review",review);

        return "reviewsubmission";
    }
    
    @RequestMapping(value = "/createNewReview", method = RequestMethod.POST)
    public String saveReview(@ModelAttribute Reviews review, Model model) {

    	partService.createNewReview(review);
    	model.addAttribute("message","New Review Added Successfully");    	
    	model.addAttribute("review",review);
  	
        return "reviewsubmission";
    } 

	
}