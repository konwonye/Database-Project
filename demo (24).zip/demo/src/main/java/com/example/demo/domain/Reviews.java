package com.example.demo.domain;

public class Reviews {
	
	private String revemail;
	private String paperID;
	private String techmerit;
	private String readability;
	private String originality;
	private String relavance;
	private String overallRecomm;
	private String commForCommittee;
	private String commForAuthor;

	public Reviews (String revemail, String paperID, String techmerit, String readability, String originality, String relavance,

	String overallRecomm, String commForAuthor, String commForCommittee) {

	super();

	this.revemail = revemail;
	
	this.paperID = paperID;

	this.techmerit = techmerit;

	this.readability = readability;

	this.originality = originality;

	this.relavance = relavance;

	this.overallRecomm = overallRecomm;

	this.commForCommittee = commForCommittee;

	this.commForAuthor = commForAuthor;

	}

	 

	public String getRevemail() {

	return revemail;

	}

	 

	public void setRevemail(String revemail) {

	this.revemail = revemail;

	}
	

	public String getPaperID() {
		return paperID;
	}
	

	public void setPaperID(String paperID) {
		this.paperID = paperID;
	}
	

	public String getTechmerit() {

	return techmerit;

	}

	public void setTechmerit(String techmerit) {

	this.techmerit = techmerit;

	}

	 

	public String getReadability() {

	return readability;

	}

	 

	public void setReadability(String readability) {

	this.readability = readability;

	}

	 

	public String getOriginality() {

	return originality;

	}

	public void setOriginality(String originality) {

	this.originality = originality;

	}

	 

	public String getRelavance() {

	return relavance;

	}

	 

	public void setRelavance(String relavance) {

	this.relavance = relavance;

	}

	 

	public String getOverallRecomm() {

	return overallRecomm;

	}

	 

	public void setOverallRecomm(String overallRecomm) {

	this.overallRecomm = overallRecomm;

	}

	 

	public String getCommForCommittee() {

	return commForCommittee;

	}

	 

	public void setCommForCommittee(String commForCommittee) {

	this.commForCommittee = commForCommittee;

	}

	 

	public String getCommForAuthor() {

	return commForAuthor;

	}

	 

	public void setCommForAuthor(String commForAuthor) {

	this.commForAuthor = commForAuthor;

	}

	 
}
