package com.example.demo.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.dao.domain.ConferenceMapper;
import com.example.demo.domain.Author;
import com.example.demo.domain.Paper;
import com.example.demo.domain.Reviewer;
import com.example.demo.domain.User;
import com.example.demo.domain.participator;

@Component
public class participatorDAO {
	
	@Autowired
	private ConferenceMapper conferenceMapper;

	public List<participator> getParticipatorList() {
		
		List<participator> participatorList = new ArrayList<participator>();
		
		//participatorList = conferenceMapper.getParticipatorList();
		
		return participatorList;
	}

	public List<participator> getPaperAuthors(Paper paper) {
		
		List<participator> PaperAuthorsList = new ArrayList<participator>();
		PaperAuthorsList = conferenceMapper.getPaperAuthors(paper);
		return PaperAuthorsList;
	}
	
	public void createNewPrticipator(participator participator) {
        // TODO Auto-generated method stub
        conferenceMapper.createNewPrticipator(participator);
       
    }

	public List<User> verifyLogin(User user) {
		// TODO Auto-generated method stub
		List<User> userList = new ArrayList<User>();
		userList= conferenceMapper.verifyLogin(user);
		return userList;
	}

	public participator getLoggedinParticipator(User user) {
		// TODO Auto-generated method stub
		participator LoggedInParticipator = new participator("", "", "", "", "", "", "");
		LoggedInParticipator = conferenceMapper.getLoggedinParticipator(user);
		return LoggedInParticipator;
	}

	public void createNewAuthorRole(Author authorRole) {

		conferenceMapper.createNewAuthorRole(authorRole);

	}

	public void createNewReviewerRole(Reviewer revRole) {

		conferenceMapper.createNewReviewerRole(revRole);

	}
}