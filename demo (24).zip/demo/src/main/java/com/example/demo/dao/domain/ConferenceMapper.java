package com.example.demo.dao.domain;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.example.demo.domain.AllPaper;
import com.example.demo.domain.Author;
import com.example.demo.domain.Paper;
import com.example.demo.domain.Reviewer;
import com.example.demo.domain.Reviews;
import com.example.demo.domain.User;
import com.example.demo.domain.Writes;
import com.example.demo.domain.participator;

@Mapper
public interface ConferenceMapper {
	
	@Select("SELECT FNAME,LNAME FROM PARTICIPATOR")
	List<participator> getParticipatorList();
	
	
	@Select("SELECT P.PAPERID,P.TITLE, P.ABSTRACT, P.FILENAME, P.CONTACTAUTHOREMAIL  FROM PAPER P, WRITES W WHERE P.PAPERID = W.PAPERID and W.EMAIL = #{email}")
	List<Paper> getAuthorPapers(User user);
 
	@Select("SELECT PAPERID, TITLE, ABSTRACT, FILENAME, CONTACTAUTHOREMAIL FROM PAPER WHERE PAPERID=#{paperId}")
	Paper PaperDetails(Paper paper);

	@Select("SELECT P.EMAIL,P.FIRSTNAME,P.LASTNAME, P.MINIT, P.PHONE, P.AFFILIATION, P.PASSWORD FROM PARTICIPATOR P, WRITES W WHERE P.EMAIL =  W.EMAIL AND PAPERID=#{paperId}")
	List<participator> getPaperAuthors(Paper paper);

	@Select("SELECT REVEMAIL, PAPERID, TECHMERIT, READABILITY, ORIGINALITY, RELAVANCE, OVERALLRECOMM, COMMENTFORAUTHOR, COMMENTFORCOMMITTEE  FROM REVIEWS WHERE PAPERID=#{paperId}")
	List<Reviews> getPaperReviews(Paper paper);
	
	//@Select("SELECT p.PaperID, p.Title, AVG(SUM(r.OverallRecomm)) FROM Paper p, REVIEWS r")
    @Select("SELECT PAPERID,TITLE, ABSTRACT, FILENAME, CONTACTAUTHOREMAIL FROM PAPER")
    public List<Paper> getPaperList();
    
    @Select("SELECT p.PAPERID, p.TITLE, ROUND(AVG(r.OVERALLRECOMM),2)avgRecommend FROM PAPER p, REVIEWS r WHERE p.PAPERID = r.PAPERID GROUP BY p.PAPERID, p.TITLE")
	public List<AllPaper> getAllPaperList();
 
	
	@Insert("insert into participator(email,firstname,lastname,minit,phone,affiliation,password) values ( #{email},#{fname},#{lname},#{initial},#{phone},#{affiliation},#{password})")
    public void createNewPrticipator(participator participator);

	@Insert("insert into reviews(REVEMAIL, PAPERID, TECHMERIT, READABILITY, ORIGINALITY, RELAVANCE, OVERALLRECOMM, COMMENTFORAUTHOR, COMMENTFORCOMMITTEE) values (#{revemail}, #{paperID}, #{techmerit}, #{readability}, #{originality}, #{relavance}, #{overallRecomm}, #{commForAuthor}, #{commForCommittee})")
	public void createNewReview(Reviews review);

	@Insert("insert into paper(PAPERID, TITLE, ABSTRACT, FILENAME, CONTACTAUTHOREMAIL) values (#{paperId}, #{title}, #{paperAbstract}, #{fileName}, #{contactAuthorEmail})")
	public void createNewPaper(Paper paper);
	
	@Insert("insert into writes(PAPERID, EMAIL) values (#{paperId}, #{email})")
	public void createNewAuthors(Writes paperAuthor);
	
	@Select("SELECT max(paperID) from PAPER")
	public Integer maxPaperID();

	@Select ("SELECT email, password from participator where email = #{email} and password = #{password}")
	public List <User> verifyLogin(User user);

	@Select("SELECT P.PAPERID,P.TITLE, P.ABSTRACT, P.FILENAME, P.CONTACTAUTHOREMAIL  FROM PAPER P, REVIEWS R WHERE P.PAPERID = R.PAPERID and R.REVEMAIL = #{email}")
	public List<Paper> getAuthorReviews(User user);

	@Select("SELECT P.EMAIL,P.FIRSTNAME,P.LASTNAME, P.MINIT, P.PHONE, P.AFFILIATION, P.PASSWORD FROM PARTICIPATOR P WHERE P.EMAIL = #{email}")
	public participator getLoggedinParticipator(User user);
	
	@Insert("insert into author(EMAIL) values (#{email})")
	public void createNewAuthorRole(Author authorRole);

	@Insert("insert into reviewer(EMAIL) values (#{email})")
	public void createNewReviewerRole(Reviewer revRole);


	
	

}

