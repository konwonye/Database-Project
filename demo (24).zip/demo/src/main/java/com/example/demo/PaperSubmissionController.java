package com.example.demo;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.domain.Paper;
import com.example.demo.domain.Writes;
import com.example.demo.service.ParticipatorServices;



@Controller
public class PaperSubmissionController {
	
	private static final Logger logger = LoggerFactory.getLogger(PaperSubmissionController.class);
	
	@Autowired
	ParticipatorServices partService;
	
    
    @RequestMapping(value = "/newPaper", method = RequestMethod.GET)
    public String newPaper(@ModelAttribute Paper paper, @ModelAttribute Writes paperAuthor, Model model, Integer nextPaperID) {

    	paper = new Paper("", "", "", "", "");
    	paperAuthor = new Writes("","");
    	
    	nextPaperID = partService.getMaxPaperID();
    	model.addAttribute("paper",paper);
    	model.addAttribute("paperAuthor", paperAuthor);
    	model.addAttribute("nextPaperID", nextPaperID);

        return "papersubmission";
    }
    
    @RequestMapping(value = "/createNewPaper", method = RequestMethod.POST)
    public String savePaper(@ModelAttribute Paper paper, @ModelAttribute Writes paperAuthor, Model model) {

    	partService.createNewPaper(paper);
    	model.addAttribute("message","New Paper Added Successfully");    	
    	model.addAttribute("paper",paper);
        return "papersubmission";
    } 
    

    
    @RequestMapping(value = "/newAuthor", method = RequestMethod.GET)
    public String newAuthor(@ModelAttribute Writes paperAuthor, Model model) {
    	paperAuthor = new Writes("","");
    	
    	model.addAttribute("paperAuthor", paperAuthor);

        return "authorSubmission";
    }
    
    @RequestMapping(value = "/addPaperAuthor", method = RequestMethod.POST)
    public String saveAut(@ModelAttribute Paper paper, @ModelAttribute Writes paperAuthor, Model model) {
    	partService.createNewAuthors(paperAuthor);
    	model.addAttribute("message"," Added as Author to Paper ID: ");  
    	model.addAttribute("paperAuthor",paperAuthor);

        return "authorSubmission";
    } 
    
    
	
}