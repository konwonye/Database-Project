package com.example.demo.domain;

 

public class Writes {
	
	private String paperId;
    private String email;
    
    
    
    public Writes(String paperId, String email) {
		super();
		this.paperId = paperId;
		this.email = email;
	}
    
	public String getPaperId() {
		return paperId;
	}
	
	public void setPaperId(String paperId) {
		this.paperId = paperId;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}


    
    

 }