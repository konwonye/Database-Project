package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.domain.participator;
import com.example.demo.domain.AllPaper;
import com.example.demo.domain.Paper;
import com.example.demo.domain.Reviews;
import com.example.demo.service.ParticipatorServices;

@Controller
public class PaperDetailsController {
	
private static final Logger logger = LoggerFactory.getLogger(HomePageController.class);
	
	@Autowired
	ParticipatorServices partService;
	
	
	  @RequestMapping(value = "/paperDetails", method = RequestMethod.GET) public
	  String paperID( Model model) {
	  model.addAttribute("SelectedPaper", new Paper ("", "", "","", "")); 
	  
      model.addAttribute("message","Enter a Paper ID to Query Paper Details");  
	  return "papersummary"; 
	  
	  }
	 
	  
	  @RequestMapping(value = "/paper", method = RequestMethod.POST) public
	  String paperStuff(@ModelAttribute Paper SelectedPaper, Model model) {
		   
        /*Paper Information*/
		Paper paper = new Paper("", "", "", "", "");  
		paper = partService.selectedPaper(SelectedPaper);
	    model.addAttribute("SelectedPaper",paper);
	    
	    /*Paper Authors*/
	    List<participator> PaperAuthorsList = new  ArrayList<participator>(); 
	    PaperAuthorsList = partService.getPaperAuthors(paper);
	    model.addAttribute("PaperAuthorsList",PaperAuthorsList);
	    
	    /*Paper Reviews*/
	    List<Reviews> PaperReviewsList = new  ArrayList<Reviews>(); 
	    PaperReviewsList = partService.getPaperReviews(paper);
	    model.addAttribute("PaperReviewsList",PaperReviewsList);
	  
	  return "papersummary"; 
	  
	  }
	 
	  
	@RequestMapping(value = "/listPapers", method = RequestMethod.GET)
    public String displayPapers(Model model) {
       
		List<AllPaper> paperList = new ArrayList<AllPaper>();    
	       
        paperList = partService.getAllPaperList();
        model.addAttribute("paperList",paperList);
        return "allPapers";
    }
	
	
	
}
