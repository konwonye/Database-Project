package com.example.demo.domain;

public class participator {
	
	private String email;
	private String fname;
	private String lname;
	private String initial;
	private String phone;
	private String affiliation;
	private String participatorType;
	private String topic_interest;
	private String password;
	
	/**
	 * @param fname
	 * @param lname
	 * @param ssn
	 */
	public participator(String email, String fname, String lname, String initial, 
			String phone, String affiliation, String participatorType,String topic_interest,String password) {
		
		
		super();
		
		
		this.email = email;
		this.fname= fname;
		this.lname =lname;
		this.initial = initial;
		this.phone = phone;
		this.affiliation = affiliation;
		this.participatorType = participatorType;
		this.topic_interest= topic_interest;
		this.password=password;
	}
	
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the fname
	 */
	public String getFname() {
		return fname;
	}
	/**
	 * @param fname the fname to set
	 */
	public void setFname(String fname) {
		this.fname = fname;
	}
	/**
	 * @return the lname
	 */
	public String getLname() {
		return lname;
	}
	/**
	 * @param lname the lname to set
	 */
	public void setLname(String lname) {
		this.lname = lname;
	}
	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}
	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}
	/**
	 * @return the affiliation
	 */
	public String getAffiliation() {
		return affiliation;
	}
	/**
	 * @param affiliation the affiliation to set
	 */
	public void setAffiliation(String affiliation) {
		this.affiliation = affiliation;
	}
	/**
	 * @return the participatorType
	 */
	public String getParticipatorType() {
		return participatorType;
	}
	/**
	 * @param participatorType the participatorType to set
	 */
	public void setParticipatorType(String participatorType) {
		this.participatorType = participatorType;
	}
	/**
	 * @return the topic_interest
	 */
	public String getTopic_interest() {
		return topic_interest;
	}
	/**
	 * @param topic_interest the topic_interest to set
	 */
	public void setTopic_interest(String topic_interest) {
		this.topic_interest = topic_interest;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}


	/**
	 * @return the initial
	 */
	public String getInitial() {
		return initial;
	}


	/**
	 * @param initial the initial to set
	 */
	public void setInitial(String initial) {
		this.initial = initial;
	}

}
