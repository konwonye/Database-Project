package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

import com.example.demo.domain.Paper;
import com.example.demo.domain.participator;
import com.example.demo.dao.participatorDAO;
import com.example.demo.dao.paperDAO;

@Component
public class ParticipatorServices {
	@Autowired
	participatorDAO participatorDAO;
	public List<participator> getParticipatorList(){
		
			List<participator> participatorList = new ArrayList<participator>();
			
			
			participatorList = participatorDAO.getParticipatorList();
			
			
			return participatorList;
		
	}

	
	@Autowired
	paperDAO paperDAO;
	public List<Paper> getAuthorPapers(){
		
			List<Paper> AuthorPaperList = new ArrayList<Paper>();
			
			
			AuthorPaperList = paperDAO.getAuthorPapers();
			
			
			return AuthorPaperList;
		
	}
}
