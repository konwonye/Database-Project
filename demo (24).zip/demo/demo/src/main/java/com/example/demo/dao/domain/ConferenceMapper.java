package com.example.demo.dao.domain;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.example.demo.domain.Paper;
import com.example.demo.domain.participator;

@Mapper
public interface ConferenceMapper {
	@Select("SELECT FNAME,LNAME FROM PARTICIPATOR")
	List<participator> getParticipatorList();
	
	
	@Select("SELECT PAPERID,TITLE FROM PAPERS")
	List<Paper> getAuthorPapers();

}
