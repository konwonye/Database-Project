package com.example.demo.dao;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.dao.domain.CompanyMapper;
import com.example.demo.dao.domain.ConferenceMapper;
import com.example.demo.domain.Paper;
import com.example.demo.domain.participator;

@Component
public class paperDAO {
	
	@Autowired
	private ConferenceMapper conferenceMapper;

	public List<Paper> getAuthorPapers() {
		
		List<Paper> AuthorPaperList = new ArrayList<Paper>();
		
		AuthorPaperList = conferenceMapper.getAuthorPapers();
		
		return AuthorPaperList;
	}

}

